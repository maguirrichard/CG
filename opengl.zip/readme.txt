QT 15.5.0, MinGW x32 
Bernardo Morais, Pedro de Souza, Maguirrichard Oliveira